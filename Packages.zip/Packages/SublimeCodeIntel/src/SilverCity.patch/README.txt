# `ScintillaConstants.py` generated running `write_scintilla.py` in the `SilverCity-0.9.7/PySilverCity/Src` folder:
cd SilverCity-0.9.7/PySilverCity/Src && python write_scintilla.py ../../../scintilla/include/ ../../../scintilla/include/Scintilla.iface ../SilverCity/ScintillaConstants.py
