# ZenCoding

## Installation

### Mac OSX (Lion)

1. Clone git repo into your packages folder (mine is ~/Library/Application Support/Sublime Text 2/Packages):

  $ cd ~/Library/Application Support/Sublime Text 2/Packages
  $ git clone https://github.com/sublimator/ZenCoding.git

2. Restart Sublime Text 2

